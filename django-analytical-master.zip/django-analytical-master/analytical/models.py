"""
Models for the django-analytical Django application.

This application currently does not use models.
"""
